from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(req):
   html = "<html><body> Blog Personal </body></html>"
   return HttpResponse(html)
